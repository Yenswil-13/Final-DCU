﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace ProyectoFinalDCU
{
    public partial class Casadecambio : Form
    {
        public Casadecambio()
        {
            InitializeComponent();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            double eu, resul;
            const double rd = 56.72;
            eu = double.Parse(textBox1.Text);
            resul = rd * eu;
            textBox2.Text = resul.ToString();
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            double eur, resul;
            const double rd = 62.05;
            eur = double.Parse(textBox1.Text);
            resul = rd * eur;
            textBox2.Text = resul.ToString();
        }

        private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            double rd, resul;
            const double eu = 56.72;
            rd = double.Parse(textBox1.Text);
            resul = rd / eu;
            textBox2.Text = resul.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox1.Focus();
        }
    }
}
