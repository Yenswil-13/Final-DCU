﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoFinalDCU
{
    public partial class NominaS : Form
    {
        public NominaS()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int lu, ma, mi, ju, vi, sa, dom, sal, he, ht, cant;

            lu = int.Parse(textBox1.Text);
            ma = int.Parse(textBox2.Text);
            mi = int.Parse(textBox3.Text);
            ju = int.Parse(textBox4.Text);
            vi = int.Parse(textBox5.Text);
            sa = int.Parse(textBox6.Text);
            dom = int.Parse(textBox7.Text);

            cant = lu + ma + mi + ju + vi + sa + dom;

            if(cant < 41)
            {
                ht = cant * 220;
                he = 0;
            }
            else
            {
                ht = 40 * 220;
                he = (cant - 40) * 300;
            }
            sal = he + ht;
            textBox8.Text = sal.ToString();
        }
        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            textBox7.Clear();
            textBox8.Clear();
            textBox1.Focus();
        }
    }
}
