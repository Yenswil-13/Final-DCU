﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Security.Cryptography.X509Certificates;

namespace ProyectoFinalDCU
{
    internal class ConexionBD
    {

        SqlCommand command;
        SqlDataReader reader;
        SqlConnection sqlcon;

        public ConexionBD()
        {

            sqlcon = new SqlConnection("Data Source=DESKTOP-BCVURIL\\MSSQLSERVER01;Initial Catalog=finaldcu;Integrated Security=True");
        }

        public SqlConnection sql_conectar()
        {
            try
            {
                sqlcon.Open();
            }
            catch
            {

            }
            return sqlcon;
        }

        public void sql_desconectar()
        {
            try
            {
                sqlcon.Close();
            }
            catch
            {

            }
        }

        public bool validar(string user, string password)
        {
            bool valid = false;
            string query = @"SELECT nombre, clave FROM dbo.usuario WHERE
                     nombre = '" + user + "' AND clave = '" + password + "'"; // Agregado el igual faltante

            command = new SqlCommand(query, sql_conectar());
            reader = command.ExecuteReader();

            if (reader.HasRows == true)
            {
                valid = true;
            }
            return valid;
        }


    }
}
