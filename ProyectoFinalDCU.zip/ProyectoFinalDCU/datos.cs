﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;
using System.Web;

namespace ProyectoFinalDCU
{
    internal class datos: ConexionBD
    {

        string query = "";
        SqlCommand comand;
        ConexionBD conexion = new ConexionBD();
        DataSet ds = new DataSet();
        SqlDataAdapter adapter;


        public DataTable sql_consultas(string tabla, string campos, string condicion)
        {
            query = "SELECT " + campos + " FROM " + tabla + " WHERE " + condicion;
            try
            {
                adapter = new SqlDataAdapter(query, conexion.sql_conectar());
                adapter.Fill(ds, "TDATOS");
            }
            catch (SqlException x)
            {
                MessageBox.Show(x.ToString());
            }
            return ds.Tables["TDATOS"];
        }


    }
}
