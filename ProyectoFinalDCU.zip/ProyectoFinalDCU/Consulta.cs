﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoFinalDCU
{
    public partial class Consulta : Form
    {
        public Consulta()
        {
            InitializeComponent();
        }

        datos datos = new datos();
        private void button1_Click(object sender, EventArgs e)
        {
            dgvConsulta.DataSource = datos.sql_consultas("usuario", "codigo as codigo, nombre as nombre, apellido as apellido, correo as correo, telefono as telefono", "nombre='" + txtBuscar.Text + "' or apellido='" + txtBuscar.Text + "'");


        }
    }
}
