﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoFinalDCU
{
    public partial class Menuprincipal : Form
    {
        public Menuprincipal()
        {
            InitializeComponent();
        }

        private void sumadoraToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Sumadora sumadora = new Sumadora();
            sumadora.Show();
        }

        private void casaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Casadecambio cambio = new Casadecambio();
            cambio.Show();
        }

        private void nominaSemanalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            NominaS nomina = new NominaS();
            nomina.Show();
        }

        private void consultaDeUsuarioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Consulta consulta = new Consulta();
            consulta.Show();
        }

        private void salirDelSistemaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
